package com.gatekeepr.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class FilterService {

    /**
     * Filtert das eingehende JSON-Objekt auf die erlaubten Felder.
     *
     * @param fullJson          Die vollständige Objektstruktur
     * @param allowedProperties Die Felder, die laut Policy sichtbar sind
     * @return Eine gefilterte Map mit nur erlaubten Feldern
     */
    public Map<String, Object> filterJson(Map<String, Object> fullJson, Collection<String> allowedProperties) {
        if (fullJson == null || allowedProperties == null) {
            log.warn("Null input detected in filtering – fullJson or allowedProperties");
            return Map.of("error", "Invalid input for filtering");
        }

        Map<String, Object> filtered = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : fullJson.entrySet()) {
            String key = entry.getKey();
            if (allowedProperties.contains(key)) {
                filtered.put(key, entry.getValue());
            }
        }

        log.debug("Filter result keys: {}", filtered.keySet());
        return filtered;
    }
}
