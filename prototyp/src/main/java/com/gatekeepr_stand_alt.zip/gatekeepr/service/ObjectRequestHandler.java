package com.gatekeepr.service;

import com.gatekeepr.client.*;
import com.gatekeepr.dto.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class ObjectRequestHandler {

    private final TransitAccessClient accessClient;
    private final FilterService filterService;
    private final SourceDataClient sourceDataClient;

    public AccessResponseDto handleRequest(AccessRequestDto req) {
        String identityId = req.getIdentityId();
        String requestedById = (req.getRequestedById() != null && !req.getRequestedById().isBlank()) ? req.getRequestedById() : identityId;
        Boolean createdByMyOwn = req.getCreatedByMyOwn();
        Integer pageSize = req.getPageSize();

        List<AccessibleObject> accessibleObjects = new ArrayList<>();

        // Fall: das nach mehreren Objekten gesucht wird
        if (req.getObjectIds() != null && !req.getObjectIds().isEmpty()) {
            for (String objectId : req.getObjectIds()) {
                if (objectId != null && !objectId.isBlank()) {
                    AccessibleObject obj = handleDirectAccess(identityId, requestedById, objectId, req.getObjectEntityClass());
                    if (obj != null) {
                        accessibleObjects.add(obj);
                    }
                }
            }
        }
        // Fall: konkrete objectId gegeben
        else if (req.getObjectId() != null && !req.getObjectId().isBlank()) {
            AccessibleObject obj = handleDirectAccess(identityId, requestedById, req.getObjectId(), req.getObjectEntityClass());
            if (obj != null) {
                accessibleObjects.add(obj);
            }
        }
        // Fall: Suche anhand von entityClass
        else if (req.getObjectEntityClass() != null && !req.getObjectEntityClass().isBlank()) {
            accessibleObjects.addAll(handleSearchAccess(identityId, requestedById, req.getObjectEntityClass(), createdByMyOwn, pageSize));
        }

        return new AccessResponseDto(
                accessibleObjects,
                "success",
                null,
                Instant.now().toString()
        );
    }

    public FilteredAccessResponseDto handleFilteredResponse(AccessRequestDto req) {
        AccessResponseDto full = handleRequest(req);

        List<Map<String, Object>> filteredDataList = full.getObjects().stream()
                .map(AccessibleObject::getFilteredData)
                .toList();

        Object data = (filteredDataList.size() == 1) ? filteredDataList.get(0) : filteredDataList;

        return new FilteredAccessResponseDto(
                data,
                full.getStatus(),
                full.getMessage(),
                full.getTimestamp()
        );
    }


    private AccessibleObject handleDirectAccess(String identityId, String requestedById, String objectId, String entityClass) {
        TransitAccessClient.AccessRights rights = accessClient.getAccessRights(objectId, identityId, requestedById);

        if (rights == null || rights.isEmpty()) {
            log.info("No access rights for object '{}', identity '{}'", objectId, identityId);
            return null;
        }

        Map<String, Object> rawData = sourceDataClient.loadObjectData(objectId, entityClass);

        Map<String, Object> filtered = filterService.filterJson(rawData, rights.getRead());

        return new AccessibleObject(
                objectId,
                entityClass,
                identityId,
                toProperties(rights),
                filtered
        );
    }

    private List<AccessibleObject> handleSearchAccess(String identityId, String requestedById, String entityClass, Boolean createdByMyOwn, Integer pageSize) {
        List<TransitAccessClient.ObjectAccess> objects = accessClient.searchAccessibleObjects(identityId, requestedById, entityClass, createdByMyOwn, pageSize);

        log.info("Found {} accessible objects from TRANSIT for identity '{}'", objects.size(), identityId);

        List<AccessibleObject> result = new ArrayList<>();
        for (TransitAccessClient.ObjectAccess o : objects) {
            Map<String, Object> raw = sourceDataClient.loadObjectData(o.getObjectId(), entityClass);
            Map<String, Object> filtered = filterService.filterJson(raw, o.getObjectProperties().getReadProperties());

            result.add(new AccessibleObject(
                    o.getObjectId(),
                    entityClass,
                    identityId,
                    o.getObjectProperties(),
                    filtered
            ));
        }        

        return result;
    }

    private ObjectProperties toProperties(TransitAccessClient.AccessRights rights) {
        return new ObjectProperties(
                new ArrayList<>(rights.getRead()),
                new ArrayList<>(rights.getWrite()),
                new ArrayList<>(rights.getSharedRead()),
                new ArrayList<>(rights.getSharedWrite())
        );
    }
}
