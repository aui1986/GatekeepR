package com.gatekeepr.dto;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessRequestDto {
    private String identityId;              // für wen wird geprüft
    private String requestedById;           // wer fragt an 
    private String objectId;                // welche ObjektID
    private List<String> objectIds;         // Liste von ObjektIDs
    private String objectEntityClass;       // welche Objektklassen
    private Map<String, Object> context;    // optional, z. B. für Uhrzeit, IP etc.
    private Boolean createdByMyOwn;         // selbst erstellt
    private Integer pageSize;               // wieviel Ergebnisse
}
