package com.gatekeepr.dto;

import com.gatekeepr.dto.AccessibleObject;
import java.time.Instant;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccessResponseDto {

    private List<AccessibleObject> objects;  // Liste der Objekte mit Rechten
    private String status;                   // z. B. "success", "error"
    private String message;                  // optional
    private String timestamp;                // z. B. ISO8601

    public static AccessResponseDto error(String msg) {
        return new AccessResponseDto(null, "error", msg, Instant.now().toString());
    }
}
