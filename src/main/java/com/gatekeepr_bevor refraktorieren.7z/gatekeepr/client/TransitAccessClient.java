package com.gatekeepr.client;

import com.gatekeepr.dto.ObjectProperties;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Slf4j
@Component
public class TransitAccessClient {

    private final RestTemplate restTemplate;
    private static final String TRANSIT_BASE_URL = "http://localhost:8085/api/v1";
    private static final String API_KEY = "614D5358726EC07655BF4A38CA751E5055FEF920ECCAC2624C";

    public TransitAccessClient() {
        this.restTemplate = new RestTemplate();
    }

    public AccessRights getAccessRights(String objectId, String identityId, String requestedById) {
        String url = TRANSIT_BASE_URL + "/access/" + objectId +
                "?identityId=" + identityId + "&requestedById=" + requestedById;

        HttpHeaders headers = new HttpHeaders();
        headers.set("X-API-KEY", API_KEY);
        HttpEntity<Void> request = new HttpEntity<>(headers);

        try {
            ResponseEntity<AccessRights> response = restTemplate.exchange(
                    url, HttpMethod.GET, request, AccessRights.class
            );
            return response.getStatusCode().is2xxSuccessful() && response.getBody() != null
                    ? response.getBody()
                    : AccessRights.empty();
        } catch (HttpClientErrorException.NotFound e) {
            log.info("No access rights found in TRANSIT for objectId='{}', identityId='{}' (404)", objectId, identityId);
        } catch (Exception e) {
            log.error("Error contacting TRANSIT system", e);            
        }
        return AccessRights.empty();
    }

    /**
     * Ruft alle Objekte ab, auf die eine Identität Zugriff hat.
     */
    public List<ObjectAccess> searchAccessibleObjects(
        String identityId,
        String requestedById,
        String entityClass,
        Boolean createdByMyOwn,
        Integer pageSize
    ) {
        StringBuilder urlBuilder = new StringBuilder(TRANSIT_BASE_URL + "/access/search/?");
        boolean useCreatedByMyOwn = (createdByMyOwn != null) ? createdByMyOwn : true;

        if (identityId != null && !identityId.isBlank()) {urlBuilder.append("identityId=").append(identityId).append("&");}

        urlBuilder.append("requestedById=").append(requestedById);        
        urlBuilder.append("&objectEntityClass=").append(entityClass);
        urlBuilder.append("&createdByMyOwn=").append(useCreatedByMyOwn);

        if (pageSize != null) {urlBuilder.append("&pagesize=").append(pageSize);}

        String url = urlBuilder.toString();

        HttpHeaders headers = new HttpHeaders();
        headers.set("X-API-KEY", API_KEY);
        HttpEntity<Void> request = new HttpEntity<>(headers);

        log.info(url);

        try {
            ResponseEntity<SearchResponse> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    request,
                    SearchResponse.class
            );

            log.info("Calling TRANSIT for accessible objects: identity={}, requestedBy={}, class={}", identityId, requestedById, entityClass);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
                return response.getBody().getObjects();
            }
        } catch (Exception e) {
            log.error("Error fetching accessible objects", e);
        }

        return Collections.emptyList();
    }

    @Data
    public static class AccessRights {
        private String objectId;
        private String objectEntityClass;
        private String identityId;
        private ObjectProperties objectProperties;

        public boolean isEmpty() {
            return objectProperties == null || objectProperties.getReadProperties().isEmpty();
        }

        public Set<String> getRead() {
            return new HashSet<>(Optional.ofNullable(objectProperties.getReadProperties()).orElse(List.of()));
        }

        public Set<String> getWrite() {
            return new HashSet<>(Optional.ofNullable(objectProperties.getWriteProperties()).orElse(List.of()));
        }

        public Set<String> getSharedRead() {
            return new HashSet<>(Optional.ofNullable(objectProperties.getShareReadProperties()).orElse(List.of()));
        }

        public Set<String> getSharedWrite() {
            return new HashSet<>(Optional.ofNullable(objectProperties.getShareWriteProperties()).orElse(List.of()));
        }

        public static AccessRights empty() {
            AccessRights ar = new AccessRights();
            ar.setObjectId(null);
            ar.setObjectEntityClass(null);
            ar.setIdentityId(null);

            ObjectProperties props = new ObjectProperties();
            props.setReadProperties(List.of());
            props.setWriteProperties(List.of());
            props.setShareReadProperties(List.of());
            props.setShareWriteProperties(List.of());

            ar.setObjectProperties(props);
            return ar;
        }
    }


    @Data
    public static class SearchResponse {
        private List<ObjectAccess> objects = List.of();
    }

    @Data
    public static class ObjectAccess {
        private String objectId;
        private String objectEntityClass;
        private String identityId;
        private ObjectProperties objectProperties;
    }
}
