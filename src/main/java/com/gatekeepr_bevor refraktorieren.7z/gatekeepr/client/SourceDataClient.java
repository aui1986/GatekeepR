package com.gatekeepr.client;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@Component
public class SourceDataClient {

    /**
     * Simuliert den Abruf von Objektdaten aus einem Quellsystem.
     *
     * @param objectId       Die Objekt-ID (z. B. UUID)
     * @param entityClass    Die Klasse des Objekts (z. B. "Vehicle", "Person", etc.)
     * @return Eine Map mit Pseudo-Daten
     */
    public Map<String, Object> loadObjectData(String objectId, String entityClass) {
        log.info("Simulating data fetch for objectId='{}', entityClass='{}'", objectId, entityClass);

        if (entityClass == null || entityClass.isBlank()) {
            entityClass = "person";
        }

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("objectId", objectId);
        data.put("objectEntityClass", entityClass);

        

        switch (entityClass.toLowerCase()) {
            case "vehicle" -> {
                data.put("licensePlate", "ABC-123");
                data.put("brand", "Opel");
                data.put("model", "Corsa");
                data.put("fuelType", "Diesel");
                data.put("mileage", 103000);
                data.put("status", "active");
            }
            case "person" -> {
                data.put("firstName", "Max");
                data.put("lastName", "Mustermann");
                data.put("email", "max@example.com");
                data.put("role", "driver");
                data.put("status", "active");
            }
            default -> {
                data.put("name", "Generic Object");
                data.put("description", "Simulated data for unknown entity class");
                data.put("status", "active");
            }
        }

        return data;
    }
}
