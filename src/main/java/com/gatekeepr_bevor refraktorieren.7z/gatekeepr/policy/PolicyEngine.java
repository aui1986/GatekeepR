package com.gatekeepr.policy;

import com.gatekeepr.dto.AccessRequestDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class PolicyEngine {

    private final RuleLoader ruleLoader;

    /**
     * Ermittelt für ein Request alle anwendbaren Regeln.
     *
     * @param request Das ursprüngliche Zugriffsersuchen
     * @return Map: Feldname → Aktion ("mask", "remove", ...)
     */
    public Map<String, String> evaluate(AccessRequestDto request) {
        Map<String, String> decisions = new HashMap<>();
        List<RuleDefinition> rules = ruleLoader.getRules();

        for (RuleDefinition rule : rules) {
            log.info("Checking rule for field '{}', condition: {}", rule.getField(), rule.getCondition());

            if (matchesCondition(rule.getCondition(), request)) {
                decisions.put(rule.getField(), rule.getAction());
            }
        }

        return decisions;
    }

    public List<RuleDefinition> getMatchingRules(AccessRequestDto request) {
        return ruleLoader.getRules().stream()
            .filter(r -> matchesCondition(r.getCondition(), request))
            .toList();
    }


    /**
     * Prüft, ob eine Regelbedingung auf den aktuellen Request zutrifft.
     * Unterstützt aktuell einfache Zeitbasierte Bedingungen.
     *
     * @param condition Regelbedingung aus JSON
     * @param request   Zugriffsrequest
     * @return true, wenn Bedingung erfüllt
     */
    private boolean matchesCondition(Map<String, Object> condition, AccessRequestDto request) {
        if (condition == null || condition.isEmpty()) return false;

        boolean matched = true;

        // Zeitbedingung
        if (condition.containsKey("time")) {
            Map<String, String> timeCond = (Map<String, String>) condition.get("time");
            LocalTime now = LocalTime.now();

            boolean afterOk = true;
            boolean beforeOk = true;

            if (timeCond.containsKey("after")) {
                LocalTime afterTime = LocalTime.parse(timeCond.get("after"));
                afterOk = now.isAfter(afterTime);
            }

            if (timeCond.containsKey("before")) {
                LocalTime beforeTime = LocalTime.parse(timeCond.get("before"));
                beforeOk = now.isBefore(beforeTime);
            }

            matched &= (afterOk && beforeOk);
        }

        // Kontextbedingung
        if (condition.containsKey("context")) {
            Map<String, String> requiredContext = (Map<String, String>) condition.get("context");
            if (request.getContext() == null) return false;

            for (Map.Entry<String, String> entry : requiredContext.entrySet()) {
                String key = entry.getKey();
                String expected = entry.getValue();
                Object actual = request.getContext().get(key);
                if (actual == null || !expected.equals(actual.toString())) {
                    matched = false;
                    break;
                }
            }
        }

        // Zugriffshäufigkeit
        if (condition.containsKey("accessCount")) {
            Map<String, Integer> countCond = (Map<String, Integer>) condition.get("accessCount");
            Object ctxVal = request.getContext() != null ? request.getContext().get("accessCount") : null;

            if (ctxVal == null) return false;

            try {
                int actualCount = Integer.parseInt(ctxVal.toString());
                if (countCond.containsKey("greaterThan")) {
                    int threshold = countCond.get("greaterThan");
                    if (!(actualCount > threshold)) return false;
                }

                //Hier können zusätzliche paramter eingefügt werden, wie equals, lessthan, etc.
            } catch (NumberFormatException e) {
                return false;
            }
        }

        //Filter wenn eine gewisse Anzahl an Datensätzen aus der PM zurückkommen um Filter nzuenden
        if (condition.containsKey("objectCount")) {
            Map<String, Integer> countCond = (Map<String, Integer>) condition.get("objectCount");

            Object ctxVal = request.getContext() != null ? request.getContext().get("objectCount") : null;
            if (ctxVal == null) return false;

            try {
                int actualCount = Integer.parseInt(ctxVal.toString());
                if (countCond.containsKey("greaterThan")) {
                    int threshold = countCond.get("greaterThan");
                    if (actualCount <= threshold) return false;
                }
            } catch (NumberFormatException e) {
                return false;
            }
        }

        // Always
        if (condition.containsKey("always")) {
            Object val = condition.get("always");
            matched &= val instanceof Boolean && (Boolean) val;
        }

        return matched;
    }


}
