package com.gatekeepr.policy;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

@Slf4j
@Component
public class RuleLoader {

    @Value("${gatekeepr.rules.path}")
    private String rulesPathProp;

    @Getter
    private List<RuleDefinition> rules = Collections.emptyList();

    @PostConstruct
    public void loadRules() {
        this.rules = readRulesFromFile();
        log.info("Loaded {} policy rules from '{}'", rules.size(), rulesPathProp);
    }

    public void reload() {
        this.rules = readRulesFromFile();
        log.info("Rules reloaded ({} entries)", rules.size());
    }

    private List<RuleDefinition> readRulesFromFile() {
        Path rulesFile = Paths.get(rulesPathProp);

        try (InputStream in = Files.newInputStream(rulesFile)) {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(in, new TypeReference<>() {});
        } catch (Exception e) {
            log.error("Error loading policy rules from '{}'", rulesFile.toAbsolutePath(), e);
            return Collections.emptyList();
        }
    }
}
