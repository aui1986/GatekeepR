package com.gatekeepr.dto;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccessibleObject {

    private String objectId;
    private String objectEntityClass;
    private String identityId;

    private ObjectProperties objectProperties;
    private Map<String, Object> filteredData;
}

