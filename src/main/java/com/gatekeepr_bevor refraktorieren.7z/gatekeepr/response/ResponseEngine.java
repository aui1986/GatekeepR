package com.gatekeepr.response;

import com.gatekeepr.dto.AccessRequestDto;
import com.gatekeepr.policy.PolicyEngine;
import com.gatekeepr.policy.RuleDefinition;
import com.gatekeepr.policy.RuleUsage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;

@Slf4j
@Component
@RequiredArgsConstructor
public class ResponseEngine {

    private final PolicyEngine policyEngine;


    public Map<String, Object> filterAndTransform(
            Map<String, Object> rawData,
            Collection<String> allowedProperties,
            AccessRequestDto request,
            Map<String, RuleUsage> ruleSummary
    ) {
        Map<String, Object> result = new LinkedHashMap<>();

        // Alle zutreffenden Regeln laden (mehrere pro Feld möglich!)
        List<RuleDefinition> matchedRules = policyEngine.getMatchingRules(request);

        // Klassenzugehörigkeit laut PM (nicht laut Request)
        String objectClass = Optional.ofNullable(rawData.get("objectEntityClass"))
                .map(Object::toString)
                .map(String::toLowerCase)
                .orElse("");

        // Gruppiert alle Regeln pro Feld (qualified und unqualified)
        Map<String, List<RuleDefinition>> rulesPerField = new HashMap<>();
        for (RuleDefinition rule : matchedRules) {
            rulesPerField
                .computeIfAbsent(rule.getField(), k -> new ArrayList<>())
                .add(rule);
        }

        for (Map.Entry<String, Object> entry : rawData.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();

            //Fügt die Objektid an erster Stelle hinzu, weitere Daten möglich
            boolean isMandatory = "objectId".equals(key); // oder auch weitere Pflichtfelder
            if (!allowedProperties.contains(key) && !isMandatory) continue;


            String qualifiedKey = objectClass + "." + key;

            // Suche alle möglichen Regeln für dieses Feld
            List<RuleDefinition> fieldRules = Optional.ofNullable(rulesPerField.get(qualifiedKey))
                    .or(() -> Optional.ofNullable(rulesPerField.get(key)))
                    .orElse(List.of());

            // Check: Gibt es eine explizite Ausnahme ("none")?
            boolean hasNoneRule = fieldRules.stream().anyMatch(r -> "none".equals(r.getAction()));
            if (hasNoneRule) {
                ruleSummary
                    .computeIfAbsent(qualifiedKey + "::none", k -> new RuleUsage(qualifiedKey, "none", Map.of("override", true)))
                    .increment();
                result.put(key, value);
                continue;
            }

            // Wende erste zutreffende Regel (z. B. remove, mask, ...) an
            boolean transformed = false;
            for (RuleDefinition rule : fieldRules) {
                String action = rule.getAction();
                String countKey = qualifiedKey + "::" + action;

                ruleSummary
                    .computeIfAbsent(countKey, k -> new RuleUsage(qualifiedKey, action, rule.getCondition()))
                    .increment();

                switch (action) {
                    case "remove" -> {
                        transformed = true;
                        break; // nicht hinzufügen
                    }
                    case "mask" -> value = applyMasking(value);
                    case "pseudonymize" -> value = applyPseudonymization(value, rule.getParameters());
                    case "generalize" -> value = applyGeneralization(value, rule.getParameters());
                }
            }

            if (!transformed) {
                result.put(key, value);
            }
        }

        return result;
    }


    private Object applyMasking(Object value) {
        if (value instanceof String s && s.length() > 3) {
            return s.substring(0, 2) + "*".repeat(Math.min(6, s.length() - 2));
        }
        return "***";
    }

    private Object applyPseudonymization(Object value, Map<String, Object> params) {
        String prefix = Optional.ofNullable(params != null ? params.get("prefix") : null)
                                .map(Object::toString)
                                .orElse("pseu");
        String suffix = Optional.ofNullable(params != null ? params.get("suffix") : null)
                                .map(Object::toString)
                                .orElse("");
        return prefix + new Random().nextInt(10000) + suffix;
    }

    private Object applyGeneralization(Object value, Map<String, Object> params) {
        if (!(value instanceof Number)) return "***";

        int roundTo = Optional.ofNullable(params.get("roundTo"))
                .map(Object::toString)
                .map(Integer::parseInt)
                .orElse(1000);

        int original = ((Number) value).intValue();
        int rounded = (original / roundTo) * roundTo;
        return rounded + "+";
    }

}
