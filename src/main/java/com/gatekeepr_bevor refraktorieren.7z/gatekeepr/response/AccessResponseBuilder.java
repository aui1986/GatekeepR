package com.gatekeepr.response;

import com.gatekeepr.dto.AccessRequestDto;
import com.gatekeepr.dto.AccessibleObject;
import com.gatekeepr.dto.ObjectProperties;
import com.gatekeepr.policy.RuleUsage;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@RequiredArgsConstructor
public class AccessResponseBuilder {

    private final ResponseEngine responseEngine;

    public AccessibleObject build(
            String objectId,
            String entityClass,
            String identityId,
            ObjectProperties rights,
            Map<String, Object> rawData,
            AccessRequestDto request,
            Map<String, RuleUsage> ruleSummary
    ) {
        Map<String, Object> filtered = responseEngine.filterAndTransform(rawData, rights.getReadProperties(), request, ruleSummary);

        return new AccessibleObject(
                objectId,
                entityClass,
                identityId,
                rights,
                filtered
        );
    }
}
