package com.gatekeepr.service;

import com.gatekeepr.client.TransitAccessClient;
import com.gatekeepr.client.TransitAccessClient.AccessRights;
import com.gatekeepr.client.TransitAccessClient.ObjectAccess;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AccessEvaluator {

    private final TransitAccessClient transit;

    public AccessRights evaluateDirectAccess(String objectId, String identityId, String requestedById) {
        return transit.getAccessRights(objectId, identityId, requestedById);
    }

    public List<ObjectAccess> evaluateSearchAccess(String identityId, String requestedById, String entityClass, Boolean createdByMyOwn, Integer pageSize) {
        return transit.searchAccessibleObjects(identityId, requestedById, entityClass, createdByMyOwn, pageSize);
    }
}
