package com.gatekeepr.service;

import com.gatekeepr.client.TransitAccessClient.AccessRights;
import com.gatekeepr.client.TransitAccessClient.ObjectAccess;
import com.gatekeepr.dto.*;
import com.gatekeepr.policy.RuleUsage;
import com.gatekeepr.response.AccessResponseBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class ObjectRequestHandler {

    private final AccessEvaluator accessEvaluator;
    private final DataFetcher dataFetcher;
    private final AccessResponseBuilder responseBuilder;

    //Dient zum speichern und protokollieren des AccessCounts mit Zeiteinheit wann das zeitintervall zurückgesetzt wird
    private final Map<String, Integer> accessCounter = new ConcurrentHashMap<>();
    private final Map<String, Long> lastAccessTime = new ConcurrentHashMap<>();
    private static final long RESET_INTERVAL_MS = 10 * 60 * 1000; //  10 Minuten


    public AccessResponseDto handleRequest(AccessRequestDto req, Map<String, RuleUsage> ruleSummary) {
        String identityId = req.getIdentityId();
        String requestedById = (req.getRequestedById() != null && !req.getRequestedById().isBlank())
                ? req.getRequestedById() : identityId;

        List<AccessibleObject> accessibleObjects = new ArrayList<>();

        if (req.getObjectIds() != null && !req.getObjectIds().isEmpty()) {
            for (String objectId : req.getObjectIds()) {
                AccessibleObject obj = handleDirectAccess(objectId, req.getObjectEntityClass(), identityId, requestedById, req, ruleSummary);
                if (obj != null) accessibleObjects.add(obj);
            }
        } else if (req.getObjectId() != null && !req.getObjectId().isBlank()) {
            AccessibleObject obj = handleDirectAccess(req.getObjectId(), req.getObjectEntityClass(), identityId, requestedById, req, ruleSummary);
            if (obj != null) accessibleObjects.add(obj);
        } else if (req.getObjectEntityClass() != null && !req.getObjectEntityClass().isBlank()) {
            accessibleObjects.addAll(handleSearchAccess(identityId, requestedById, req, ruleSummary));
        }

        //DEBUG: Log für Countermap
        log.info("---- Aktueller Zugriffszähler (accessCounter) ----");
        accessCounter.forEach((key, value) ->
            log.info("Key='{}' → Count={}", key, value)
        );
        log.info("-----------------------------------------------");

        return new AccessResponseDto(accessibleObjects, "success", null, Instant.now().toString());
    }

    public FilteredAccessResponseDto handleFilteredResponse(AccessRequestDto req) {
        Map<String, RuleUsage> ruleSummary = new HashMap<>();
        AccessResponseDto full = handleRequest(req, ruleSummary);
        List<Map<String, Object>> filtered = full.getObjects().stream()
                .map(AccessibleObject::getFilteredData).toList();

        Object data = (filtered.size() == 1) ? filtered.get(0) : filtered;

        //Ausgabe der angewendeten aggregierten Filterregeln
        if (!ruleSummary.isEmpty()) {
            log.info("-------------------------------------------------------");
            log.info("Applied rule summary ({} rules):", ruleSummary.size());
            ruleSummary.values().forEach(usage ->
                log.info("field='{}', action='{}', condition={}, affectedObjects={}",
                    usage.getField(), usage.getAction(), usage.getCondition(), usage.getCount())
            );
            log.info("-------------------------------------------------------");
        }

        return new FilteredAccessResponseDto(
                data,
                full.getStatus(),
                full.getMessage(),
                full.getTimestamp()
        );
    }

    private AccessibleObject handleDirectAccess(String objectId, String entityClass, String identityId, String requestedById, AccessRequestDto req, Map<String, RuleUsage> ruleSummary) {
        
        //Speichert den Zugriff einer ID auf ein Objekt und erhöht einen Counter
        updateAccessCount(identityId, requestedById, objectId, req);
        
        AccessRights rights = accessEvaluator.evaluateDirectAccess(objectId, identityId, requestedById);
        if (rights == null || rights.isEmpty()) {
            log.info("No access rights for object '{}', identity '{}'", objectId, identityId);
            return null;
        }

        Map<String, Object> rawData = dataFetcher.fetchRawData(objectId, entityClass);

        return responseBuilder.build(
                objectId,
                entityClass,
                identityId,
                toProperties(rights),
                rawData,
                req,
                ruleSummary
        );
    }

    private List<AccessibleObject> handleSearchAccess(String identityId, String requestedById, AccessRequestDto req, Map<String, RuleUsage> ruleSummary) {
        List<ObjectAccess> accessList = accessEvaluator.evaluateSearchAccess(
                identityId,
                requestedById,
                req.getObjectEntityClass(),
                req.getCreatedByMyOwn(),
                req.getPageSize()
        );

        //Speichert die Anzahl der von der zurückgelieferten Datensätze zur verwendung mit ObjectCount Filter
        if (req.getContext() == null) {
            req.setContext(new HashMap<>());
        }
        req.getContext().put("objectCount", accessList.size());


        List<AccessibleObject> results = new ArrayList<>();
        for (ObjectAccess o : accessList) {
            updateAccessCount(identityId, requestedById, o.getObjectId(), req);

            Map<String, Object> raw = dataFetcher.fetchRawData(o.getObjectId(), req.getObjectEntityClass());
            results.add(responseBuilder.build(
                    o.getObjectId(),
                    req.getObjectEntityClass(),
                    identityId,
                    o.getObjectProperties(),
                    raw,
                    req,
                    ruleSummary
            ));
        }

        return results;
    }

    private ObjectProperties toProperties(AccessRights rights) {
        return new ObjectProperties(
                new ArrayList<>(rights.getRead()),
                new ArrayList<>(rights.getWrite()),
                new ArrayList<>(rights.getSharedRead()),
                new ArrayList<>(rights.getSharedWrite())
        );
    }

    //  Convenience-Methode für ungefilterte Requests (z. B. /request-Endpunkt)
    public AccessResponseDto handleRequest(AccessRequestDto req) {
        return handleRequest(req, new HashMap<>());
    }

    private void updateAccessCount(String identityId, String requestedById, String objectId, AccessRequestDto req) {
        if (identityId == null || identityId.isBlank()) {
            identityId = requestedById;
        }

        String key = identityId + ":" + requestedById + "::" + objectId;
        long now = System.currentTimeMillis();

        Long lastAccess = lastAccessTime.get(key);
        if (lastAccess != null && (now - lastAccess) > RESET_INTERVAL_MS) {
            accessCounter.put(key, 1); // zurücksetzen auf 1
        } else {
            accessCounter.merge(key, 1, Integer::sum);
        }

        lastAccessTime.put(key, now);
        int count = accessCounter.getOrDefault(key, 1);

        if (req.getContext() == null) {
            req.setContext(new HashMap<>());
        }
        req.getContext().put("accessCount", count);
    }

}
