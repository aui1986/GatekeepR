package com.gatekeepr.controller;

import com.gatekeepr.dto.AccessRequestDto;
import com.gatekeepr.dto.AccessResponseDto;
import com.gatekeepr.dto.FilteredAccessResponseDto;
import com.gatekeepr.service.ObjectRequestHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/gatekeepr")
@RequiredArgsConstructor
@Slf4j
public class GatekeepRController {

    private final ObjectRequestHandler objectRequestHandler;

        private String validateRequest(AccessRequestDto dto) {
            
            boolean hasSingle = dto.getObjectId() != null && !dto.getObjectId().isBlank();
            boolean hasMultiple = dto.getObjectIds() != null && !dto.getObjectIds().isEmpty();
            boolean hasEntityClass = dto.getObjectEntityClass() != null && !dto.getObjectEntityClass().isBlank();

            if (!hasSingle && !hasMultiple && !hasEntityClass) {
                return "Either objectId, objectIds, or objectEntityClass must be provided";
            }

            // Bei direktem Zugriff ist identityId Pflicht
            if (hasSingle && (dto.getIdentityId() == null || dto.getIdentityId().isBlank())) {
                return "identityId is required when accessing a specific object";
            }

        return null; // alles ok
    }

    @PostMapping("/request")
    public ResponseEntity<AccessResponseDto> handleAccessRequest(@RequestBody AccessRequestDto requestDto) {
        log.info("Incoming access request: identityId='{}', requestedById='{}', objectId='{}', entityClass='{}'",
                requestDto.getIdentityId(),
                requestDto.getRequestedById(),
                requestDto.getObjectId(),
                requestDto.getObjectEntityClass());

        String validationError = validateRequest(requestDto);
        if (validationError != null) {
            return ResponseEntity.badRequest().body(AccessResponseDto.error(validationError));
        }

        AccessResponseDto response = objectRequestHandler.handleRequest(requestDto);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/filtered")
    public ResponseEntity<FilteredAccessResponseDto> getFilteredDataOnly(@RequestBody AccessRequestDto requestDto) {
        log.info("Incoming filtered access request: ...");

        String validationError = validateRequest(requestDto);
        if (validationError != null) {
            return ResponseEntity.badRequest().body(
                new FilteredAccessResponseDto(null, "error", validationError, java.time.ZonedDateTime.now().toString())
            );
        }

        FilteredAccessResponseDto response = objectRequestHandler.handleFilteredResponse(requestDto);
        return ResponseEntity.ok(response);
    }
}
