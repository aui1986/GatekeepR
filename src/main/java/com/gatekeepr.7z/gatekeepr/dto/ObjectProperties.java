package com.gatekeepr.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ObjectProperties {
    private List<String> readProperties = List.of();
    private List<String> writeProperties = List.of();
    private List<String> shareReadProperties = List.of();
    private List<String> shareWriteProperties = List.of();
}

