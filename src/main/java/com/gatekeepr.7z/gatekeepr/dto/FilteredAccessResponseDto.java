package com.gatekeepr.dto;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
public class FilteredAccessResponseDto {
    private Object data;       
    private String status;
    private String message;
    private String timestamp;
}
