package com.gatekeepr.service;

import com.gatekeepr.client.TransitAccessClient.AccessRights;
import com.gatekeepr.client.TransitAccessClient.ObjectAccess;
import com.gatekeepr.dto.*;
import com.gatekeepr.policy.RuleUsage;
import com.gatekeepr.response.AccessResponseBuilder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class ObjectRequestHandler {

    private final AccessEvaluator accessEvaluator;
    private final DataFetcher dataFetcher;
    private final AccessResponseBuilder responseBuilder;

    public AccessResponseDto handleRequest(AccessRequestDto req, Map<String, RuleUsage> ruleSummary) {
        String identityId = req.getIdentityId();
        String requestedById = (req.getRequestedById() != null && !req.getRequestedById().isBlank())
                ? req.getRequestedById() : identityId;

        List<AccessibleObject> accessibleObjects = new ArrayList<>();

        if (req.getObjectIds() != null && !req.getObjectIds().isEmpty()) {
            for (String objectId : req.getObjectIds()) {
                AccessibleObject obj = handleDirectAccess(objectId, req.getObjectEntityClass(), identityId, requestedById, req, ruleSummary);
                if (obj != null) accessibleObjects.add(obj);
            }
        } else if (req.getObjectId() != null && !req.getObjectId().isBlank()) {
            AccessibleObject obj = handleDirectAccess(req.getObjectId(), req.getObjectEntityClass(), identityId, requestedById, req, ruleSummary);
            if (obj != null) accessibleObjects.add(obj);
        } else if (req.getObjectEntityClass() != null && !req.getObjectEntityClass().isBlank()) {
            accessibleObjects.addAll(handleSearchAccess(identityId, requestedById, req, ruleSummary));
        }

        return new AccessResponseDto(accessibleObjects, "success", null, Instant.now().toString());
    }

    public FilteredAccessResponseDto handleFilteredResponse(AccessRequestDto req) {
        Map<String, RuleUsage> ruleSummary = new HashMap<>();
        AccessResponseDto full = handleRequest(req, ruleSummary);
        List<Map<String, Object>> filtered = full.getObjects().stream()
                .map(AccessibleObject::getFilteredData).toList();

        Object data = (filtered.size() == 1) ? filtered.get(0) : filtered;

        //Ausgabe der angewendeten aggregierten Filterregeln
        if (!ruleSummary.isEmpty()) {
            log.info("-------------------------------------------------------");
            log.info("Applied rule summary ({} rules):", ruleSummary.size());
            ruleSummary.values().forEach(usage ->
                log.info("field='{}', action='{}', condition={}, affectedObjects={}",
                    usage.getField(), usage.getAction(), usage.getCondition(), usage.getCount())
            );
            log.info("-------------------------------------------------------");
        }

        return new FilteredAccessResponseDto(
                data,
                full.getStatus(),
                full.getMessage(),
                full.getTimestamp()
        );
    }

    private AccessibleObject handleDirectAccess(String objectId, String entityClass, String identityId, String requestedById, AccessRequestDto req, Map<String, RuleUsage> ruleSummary) {
        AccessRights rights = accessEvaluator.evaluateDirectAccess(objectId, identityId, requestedById);
        if (rights == null || rights.isEmpty()) {
            log.info("No access rights for object '{}', identity '{}'", objectId, identityId);
            return null;
        }

        Map<String, Object> rawData = dataFetcher.fetchRawData(objectId, entityClass);

        return responseBuilder.build(
                objectId,
                entityClass,
                identityId,
                toProperties(rights),
                rawData,
                req,
                ruleSummary
        );
    }

    private List<AccessibleObject> handleSearchAccess(String identityId, String requestedById, AccessRequestDto req, Map<String, RuleUsage> ruleSummary) {
        List<ObjectAccess> accessList = accessEvaluator.evaluateSearchAccess(
                identityId,
                requestedById,
                req.getObjectEntityClass(),
                req.getCreatedByMyOwn(),
                req.getPageSize()
        );

        List<AccessibleObject> results = new ArrayList<>();
        for (ObjectAccess o : accessList) {
            Map<String, Object> raw = dataFetcher.fetchRawData(o.getObjectId(), req.getObjectEntityClass());
            results.add(responseBuilder.build(
                    o.getObjectId(),
                    req.getObjectEntityClass(),
                    identityId,
                    o.getObjectProperties(),
                    raw,
                    req,
                    ruleSummary
            ));
        }

        return results;
    }

    private ObjectProperties toProperties(AccessRights rights) {
        return new ObjectProperties(
                new ArrayList<>(rights.getRead()),
                new ArrayList<>(rights.getWrite()),
                new ArrayList<>(rights.getSharedRead()),
                new ArrayList<>(rights.getSharedWrite())
        );
    }

    //  Convenience-Methode für ungefilterte Requests (z. B. /request-Endpunkt)
    public AccessResponseDto handleRequest(AccessRequestDto req) {
        return handleRequest(req, new HashMap<>());
    }
}
