package com.gatekeepr.service;

import com.gatekeepr.client.SourceDataClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class DataFetcher {

    private final SourceDataClient source;

    public Map<String, Object> fetchRawData(String objectId, String entityClass) {
        return source.loadObjectData(objectId, entityClass);
    }
}
