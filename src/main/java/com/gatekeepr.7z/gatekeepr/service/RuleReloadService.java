package com.gatekeepr.service;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.gatekeepr.policy.RuleLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
@Service
@RequiredArgsConstructor
public class RuleReloadService {

    private final RuleLoader ruleLoader;

    @Value("${gatekeepr.rules.path}")
    private String rulesPathProp;

    private Path rulesPath;
    private long lastModified = 0L;

    @PostConstruct
    public void init() {
        try {
            this.rulesPath = Paths.get(rulesPathProp);
            if (Files.exists(rulesPath)) {
                lastModified = Files.getLastModifiedTime(rulesPath).toMillis();
                log.info("Initial rule file detected: {}", rulesPath.toAbsolutePath());
            }
        } catch (Exception e) {
            log.warn("Could not initialize RuleReloadService", e);
        }
    }

    @Scheduled(fixedDelay = 5000)
    public void checkForUpdates() {
        try {
            if (!Files.exists(rulesPath)) return;

            long currentModified = Files.getLastModifiedTime(rulesPath).toMillis();

            if (currentModified > lastModified) {
                log.info("Detected change in '{}', reloading rules...", rulesPath.toAbsolutePath());
                ruleLoader.reload();
                lastModified = currentModified;
            }

        } catch (Exception e) {
            log.error("Error while checking for rule updates", e);
        }
    }
}
