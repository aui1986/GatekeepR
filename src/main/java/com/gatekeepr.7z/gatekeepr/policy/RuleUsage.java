package com.gatekeepr.policy;

import java.util.Map;

public class RuleUsage {
    private final String field;
    private final String action;
    private final Map<String, Object> condition;
    private int count = 0;

    public RuleUsage(String field, String action, Map<String, Object> condition) {
        this.field = field;
        this.action = action;
        this.condition = condition;
    }

    public void increment() {
        count++;
    }

    public String getField() {
        return field;
    }

    public String getAction() {
        return action;
    }

    public Map<String, Object> getCondition() {
        return condition;
    }

    public int getCount() {
        return count;
    }
}
