package com.gatekeepr.policy;

import lombok.Data;
import java.util.Map;

@Data
public class RuleDefinition {
    private String field;
    private String action; // z. B. "mask", "remove", "pseudonymize"
    private Map<String, Object> condition; // z. B. { "time": { "after": "18:00" }, ... }
    private Map<String, Object> parameters;  // zusätzliche Einstellungen je nach Aktion
}
